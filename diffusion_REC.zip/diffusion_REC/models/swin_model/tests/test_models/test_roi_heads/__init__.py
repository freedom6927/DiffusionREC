from .utils import _dummy_bbox_sampling

__all__ = ['_dummy_bbox_sampling']
